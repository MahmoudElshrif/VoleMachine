#include <iostream>
#include "A1_T4_s20_20230375_20230030_20230507_MachineUI.h"


using namespace std;


int main()
{
	MachineUI m;
}
